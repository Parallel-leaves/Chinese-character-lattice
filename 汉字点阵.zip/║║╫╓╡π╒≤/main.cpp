#include <stdio.h>
#include <stdlib.h>
#include <cxcore.h>
#include <highgui.h>
//#include <direct.h>
#include <unistd.h>
using namespace cv;

const int CC_SIZE = 16;
const int SAFE_WIDTH = 10;
const int CC_NUMBER = 15;
// ����
unsigned char name[5] = "�";
unsigned int name_code[2][2];

// ѧ��
unsigned int id_code[12][2] = { { 0xa3, 0xb6 }, { 0xa3, 0xb3 }, { 0xa3, 0xb1 }, { 0xa3, 0xb9 }, { 0xa3, 0xb0 }, { 0xa3, 0xb0 }, { 0xa3, 0xb0 }, { 0xa3, 0xb0 }, { 0xa3, 0xb0 }, { 0xa3, 0xb3 }, { 0xa3, 0xb1 }, { 0xa3, 0xb1 } };

// �����ֽڵ�����
unsigned char mat[16][2];

FILE* HZK16;
IplImage* img;

void get_area_position_codes();

void get_mat(int a_code, int p_code);

void open_file();

void draw_one_cc(int num);

void release();


int main()
{
	open_file();
	get_area_position_codes();
	// д����
	int i, j;
	for (i = 0; i < 2; ++i)
	{
		get_mat(name_code[i][0], name_code[i][1]);
		draw_one_cc(i);
	}
	// дѧ��
	for (j = 0; j < 12; ++j)
	{
		get_mat(id_code[j][0] - 0xa0, id_code[j][1] - 0xa0);
		draw_one_cc(i + j);
	}
	// ��ʾͼƬ
        //cvSaveImage("IMAGE", img);
	cvShowImage("IMAGE", img);
	cvWaitKey(0);
	release();
	return 0;
}

void get_area_position_codes()
{
	for (int i = 0; i < 3; ++i)
	for (int j = 0; j < 2; ++j)
		name_code[i][j] = name[i * 2 + j] - 0xa0;
}

void get_mat(int a_code, int p_code)
{
	long offset;
	offset = (94 * (a_code - 1) + (p_code - 1)) * 32L;
	// ��ȡ���ݴ�������
	fseek(HZK16, offset, SEEK_SET);
	fread(mat, 32, 1, HZK16);
}

void open_file()
{
	char pbuf[100];
	getcwd(pbuf, 100);
	strcat(pbuf,"HZKf1616.hz");
	// ��ȡͼƬ
	if ((img = cvLoadImage("image.png")) == NULL)exit(1);
	// �������ļ�
	if ((HZK16 = fopen("HZKf1616.hz", "rb")) == NULL)exit(1);
}

void draw_one_cc(int num)
{
	// ͼƬ������ֵ
	int width, height;
	width = img->width;
	height = img->height;
	// ��ʼ��x y���ص�
	int start_x, start_y, size, current_start_x, current_start_y;
	size = CC_SIZE + SAFE_WIDTH;
	start_x = width - CC_NUMBER * size;
	start_y = height - CC_SIZE - SAFE_WIDTH;
	// ��ʼ����
	CvScalar cs;
	for (int i = 0; i < 16; ++i)
	for (int j = 0; j < 2; ++j)
	for (int k = 0; k < 8; k++)
	if (mat[i][j] & (0x80 >> k))
	{
		// ���
		current_start_x = j * 8 + k + start_x + size * num;
		current_start_y = start_y + i;
		cs = cvGet2D(img, current_start_y, current_start_x);
		cs.val[0] = 0;
		cs.val[1] = 255;
		cs.val[2] = 0;
		cvSet2D(img, current_start_y, current_start_x, cs);
	}
}

void release()
{
	cvReleaseImage(&img);
	fclose(HZK16);
	img = NULL;
	HZK16 = NULL;
}
